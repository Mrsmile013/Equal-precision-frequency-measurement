#ifndef _GPIO_H
#define _GPIO_H



void GPIO_GATING(void);

void KEY_Init(void);









#endif



