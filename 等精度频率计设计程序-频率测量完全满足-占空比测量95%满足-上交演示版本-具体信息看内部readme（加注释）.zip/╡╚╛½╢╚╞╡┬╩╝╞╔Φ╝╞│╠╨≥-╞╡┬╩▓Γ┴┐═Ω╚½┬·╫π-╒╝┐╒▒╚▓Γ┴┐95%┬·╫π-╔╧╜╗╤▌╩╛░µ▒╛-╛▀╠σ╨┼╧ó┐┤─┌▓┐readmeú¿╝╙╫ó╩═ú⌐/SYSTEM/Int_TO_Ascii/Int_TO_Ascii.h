#ifndef __Int_To_Ascii_H
#define __Int_To_Ascii_H


/*.h声明*/
unsigned char *my_int_to_ascii(unsigned char *array,  int value);
/*.h声明*/












#endif

