#include "lcd1602.h"
#include "delay.h"

u8 num[]="123456789101    "; 
u8 a[]=  "Zhang HaoWen    ";
u8 b[]=  "123456789101    ";
u8 c[]=  "123456789101    ";
u8 d[]=  "banbenhao 1.0   ";

#define DATA (GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15)
#define rs (GPIO_Pin_1)
#define rw (GPIO_Pin_2)
#define e (GPIO_Pin_0)

void GPIOINIT(void)	  //�˿ڳ�ʼ��
{
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin=DATA|rs|rw|e;
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStructure);
}

u8 readbusy(void)	//æ�źż��
{		
	u8 f;	
	GPIO_ResetBits(GPIOB,rs);		
	GPIO_SetBits(GPIOB,rw);
	GPIO_SetBits(GPIOB,e);	
	f=((GPIO_ReadInputData(GPIOB)&0X8000));
	delay_ms(10);
	GPIO_ResetBits(GPIOB,e);
	return f;		
}
void lcdwrc(u8 c)		 //д��λ����
{	
	while(readbusy());
	GPIO_ResetBits(GPIOB,rs);		
	GPIO_ResetBits(GPIOB,rw);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
	GPIOB->BSRR = c<<8 & 0xff00;  //�������͵�P0�� 
    GPIOB->BRR = ((~c)<<8) & 0xff00;

	delay_ms(1);
	GPIO_SetBits(GPIOB,e);
	delay_ms(1);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
}
void lcdwrd(long dat)				  //����λ����ͨ��4������
{
	while(readbusy());		
	GPIO_SetBits(GPIOB,rs);		
	GPIO_ResetBits(GPIOB,rw);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
	GPIOB->BSRR = dat<<8 & 0xff00;  //�������͵�P0�� 
    GPIOB->BRR = ((~dat)<<8) & 0xff00;
	delay_ms(1);
	GPIO_SetBits(GPIOB,e);
	delay_ms(1);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
	GPIO_ResetBits(GPIOB,rs);
	delay_ms(1);
}
void lcdinit(void)					//LCD��ʼ��
{
	delay_ms(15);
	lcdwrc(0x38);
	delay_ms(5);	
	lcdwrc(0x08);
	delay_ms(5);
	lcdwrc(0x01);
	delay_ms(5);
//	lcdwrc(0x07);	//
	delay_ms(5);
	lcdwrc(0x0c);
	delay_ms(5);
}
void lcdwrc4bit(long c)				  //д8λ����,ͨ��4������
{	
	while(readbusy());
	GPIO_ResetBits(GPIOB,rs);		
	GPIO_ResetBits(GPIOB,rw);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
	GPIOB->BSRR = c<<8 & 0xf000;  //�������͵�P0�� 
    GPIOB->BRR = ((~c)<<8) & 0xf000;
	delay_ms(1);
	GPIO_SetBits(GPIOB,e);
	delay_ms(1);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);

	GPIOB->BSRR = c<<12 & 0xf000;  //�������͵�P0�� 
    GPIOB->BRR = ((~c)<<12) & 0xf000;
	delay_ms(1);
	GPIO_SetBits(GPIOB,e);
	delay_ms(1);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
}

void lcdwrd4(long dat)				  //����λ����ͨ��4������
{
	while(readbusy());		
	GPIO_SetBits(GPIOB,rs);		
	GPIO_ResetBits(GPIOB,rw);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
	GPIOB->BSRR = dat<<8 & 0xf000;  //�������͵�P0�� 
    GPIOB->BRR = ((~dat)<<8) & 0xf000;
	delay_ms(1);
	GPIO_SetBits(GPIOB,e);
	delay_ms(1);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
	GPIOB->BSRR = dat<<12 & 0xf000;  //�������͵�P0�� 
    GPIOB->BRR = ((~dat)<<12) & 0xf000;
	delay_ms(1);
	GPIO_SetBits(GPIOB,e);
	delay_ms(1);
	GPIO_ResetBits(GPIOB,e);
	delay_ms(1);
	GPIO_ResetBits(GPIOB,rs);
}
void lcdinit4(void)					//LCD��ʼ��
{
	delay_ms(15);
	lcdwrc4bit(0x32);
	delay_ms(5);	
	lcdwrc4bit(0x28);
	delay_ms(5);
	lcdwrc4bit(0x08);
	delay_ms(5);
	lcdwrc4bit(0x01);
	delay_ms(5);
//	lcdwrc4bit(0x07);	//
	delay_ms(5);
	lcdwrc4bit(0x0c);
	delay_ms(5);
}
void display4(void)				 //��ʾ
{
	u8 i;
	lcdwrc4bit(0x00+0x80);	
	for(i=0;i<16;i++)
	{
		lcdwrd4(a[i]);
		delay_ms(500);	
	}
	lcdwrc4bit(0x40+0x80);	
	for(i=0;i<16;i++)
	{
		lcdwrd4(b[i]);
		delay_ms(500);	
	}
	lcdwrc4bit(0x07);
}
void display(void)				 //��ʾ
{
	u8 i;
	lcdwrc(0x00+0x80);	
	for(i=0;i<16;i++)
	{
		lcdwrd(a[i]);
		delay_ms(20);	
	}
	lcdwrc(0x40+0x80);	
	for(i=0;i<16;i++)
	{
		lcdwrd(b[i]);
		delay_ms(20);	
	}
	lcdwrc(0x00+0x80);	
	for(i=0;i<16;i++)
	{
		lcdwrd(c[i]);
		delay_ms(20);	
	}
	lcdwrc(0x40+0x80);	
	for(i=0;i<16;i++)
	{
		lcdwrd(d[i]);
		delay_ms(20);	
	}
}

